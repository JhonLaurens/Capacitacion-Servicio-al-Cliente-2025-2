// Coltefinanciera Training Presentation App with SCORM Integration
class PresentationApp {
    constructor() {
        this.currentSlide = 1;
        this.totalSlides = 18;
        this.slideTimers = {
            1: "0:10", 2: "0:25", 3: "0:20", 4: "0:25", 5: "0:30",
            6: "0:25", 7: "0:30", 8: "0:35", 9: "0:25", 10: "0:25",
            11: "0:30", 12: "0:35", 13: "0:40", 14: "0:30", 15: "0:25",
            16: "0:20", 17: "0:45", 18: "0:15"
        };
        
        // SCORM Integration
        this.scormAPI = null;
        this.visitedSlides = new Set();
        this.quizCompleted = false;
        this.finalScore = 0;
        
        // Quiz system properties
        this.quizData = [
            {
                question: "La nueva tipología que reemplaza a 'SI' es:",
                options: ["Solicitudes", "Peticiones", "Información", "Servicios"],
                correct: 1,
                explanation: "Las solicitudes de información, incluyendo estados de cuenta, se clasifican como PETICIONES según la nueva tipología establecida por Auditoría Interna."
            },
            {
                question: "¿Cuál es el numeral del procedimiento PR-M4-P2-01 que trata la radicación?",
                options: ["6.1.1", "6.1.2", "6.2.1", "6.2.2"],
                correct: 1,
                explanation: "El numeral 6.1.2 del procedimiento PR-M4-P2-01 establece los pasos para la radicación de requerimientos de Servicio al Cliente."
            },
            {
                question: "¿Qué genera la información incompleta en INTERCAPTA?",
                options: ["Mejores respuestas", "Reprocesos en SARO", "Mayor satisfacción", "Procesos más rápidos"],
                correct: 1,
                explanation: "La información incompleta en INTERCAPTA genera reprocesos en SARO, respuestas inconsistentes y pérdida de confianza del cliente."
            },
            {
                question: "¿Cuántas preguntas mínimo debe responder el análisis de causa raíz?",
                options: ["2", "3", "4", "5"],
                correct: 2,
                explanation: "El análisis de causa raíz debe responder 4 preguntas: ¿Qué pasó?, ¿Por qué pasó?, ¿Por qué esa causa?, ¿Cómo evitarlo?"
            },
            {
                question: "¿Hasta qué hora se puede contactar clientes los sábados según Ley 2300?",
                options: ["5:00 p.m.", "6:00 p.m.", "3:00 p.m.", "7:00 p.m."],
                correct: 2,
                explanation: "Según la Ley 2300 de 2023, los sábados se puede contactar clientes hasta las 3:00 p.m."
            },
            {
                question: "¿Quién es el Defensor del Consumidor Financiero principal?",
                options: ["Christiam Infante", "Dr. Darío Laguado", "El gerente de servicio", "Un funcionario externo"],
                correct: 1,
                explanation: "El Dr. Darío Laguado Giraldo es el Defensor del Consumidor Financiero principal, con Christiam Infante como suplente."
            },
            {
                question: "Las PETICIONES incluyen:",
                options: ["Solo quejas", "Solo reclamos", "Solicitudes de información y trámites", "Solo sugerencias"],
                correct: 2,
                explanation: "Las PETICIONES incluyen solicitudes de información general, peticiones de documentos, trámites administrativos y requerimientos específicos."
            },
            {
                question: "¿Qué debe hacerse cuando hay inconsistencias en la radicación?",
                options: ["Ignorarlas", "Recibir retroalimentación inmediata", "Reportar al mes siguiente", "Archivar el caso"],
                correct: 1,
                explanation: "Cuando hay inconsistencias en la radicación, se debe recibir retroalimentación inmediata del supervisor para mejorar."
            },
            {
                question: "SARO significa:",
                options: ["Sistema de Atención y Respuesta Operativa", "Servicio de Administración y Registro Oficial", "Sistema de Administración de Riesgo Operativo", "Servicio de Atención y Resolución Online"],
                correct: 2,
                explanation: "SARO significa Sistema de Administración de Riesgo Operativo, donde se procesan los casos de manera trazable."
            },
            {
                question: "¿Cuál es uno de los 5 compromisos del SAC?",
                options: ["Procesar rápidamente", "Cumplir lo prometido", "Generar más ventas", "Reducir costos"],
                correct: 1,
                explanation: "Uno de los 5 compromisos inquebrantables del SAC es 'Cumplir lo prometido' - cada compromiso es sagrado."
            }
        ];
        
        this.currentQuestion = 0;
        this.quizAnswers = [];
        this.quizStarted = false;
        this.quizCompleted = false;
        this.startTime = null;
        this.participantName = "";
        
        this.init();
    }

    init() {
        this.initSCORM();
        this.bindEvents();
        this.updateDisplay();
        this.showSlide(1);
    }

    /**
     * Inicializa la integración SCORM
     */
    initSCORM() {
        // Esperar a que la API SCORM esté disponible
        setTimeout(() => {
            if (window.scormAPI) {
                this.scormAPI = window.scormAPI;
                console.log('SCORM API integrada exitosamente');
                
                // Verificar estado inicial
                const status = this.scormAPI.getStatus();
                console.log('Estado SCORM inicial:', status);
                
                // Si ya está completado, mostrar mensaje
                if (status.lessonStatus === 'passed' || status.lessonStatus === 'completed') {
                    this.showCompletionMessage();
                }
            } else {
                console.log('Funcionando en modo standalone (sin SCORM)');
            }
        }, 1000);
    }

    /**
     * Actualiza el progreso en SCORM
     */
    updateSCORMProgress() {
        if (!this.scormAPI) return;
        
        // Marcar slide como visitado
        this.visitedSlides.add(this.currentSlide);
        
        // Calcular progreso basado en slides visitados
        const progressPercent = (this.visitedSlides.size / this.totalSlides) * 100;
        
        // Enviar progreso al LMS
        this.scormAPI.setProgress(progressPercent);
        
        console.log(`Progreso SCORM: ${progressPercent.toFixed(1)}% (${this.visitedSlides.size}/${this.totalSlides} slides)`);
        
        // Si visitó todos los slides, marcar como completado
        if (this.visitedSlides.size >= this.totalSlides) {
            this.scormAPI.setStatus('completed');
        }
    }

    /**
     * Envía la puntuación final al LMS
     */
    submitSCORMScore(score) {
        if (!this.scormAPI) return;
        
        this.finalScore = score;
        this.scormAPI.setScore(score, 100, 0);
        
        console.log(`Puntuación SCORM enviada: ${score}/100`);
        
        // Marcar quiz como completado
        this.quizCompleted = true;
        
        // Si aprobó, marcar como pasado
        if (score >= 80) {
            this.scormAPI.setStatus('passed');
        } else {
            this.scormAPI.setStatus('failed');
        }
    }

    /**
     * Muestra mensaje de finalización
     */
    showCompletionMessage() {
        const message = document.createElement('div');
        message.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 15px;
            border-radius: 8px;
            z-index: 1000;
            font-weight: bold;
        `;
        message.textContent = '✅ Capacitación ya completada';
        document.body.appendChild(message);
        
        setTimeout(() => {
            message.remove();
        }, 5000);
    }

    bindEvents() {
        // Navigation buttons
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const restartBtn = document.getElementById('restartBtn');

        prevBtn.addEventListener('click', () => this.previousSlide());
        nextBtn.addEventListener('click', () => this.nextSlide());
        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartPresentation());
        }

        // Quiz buttons
        const startQuizBtn = document.getElementById('startQuizBtn');
        if (startQuizBtn) {
            startQuizBtn.addEventListener('click', () => this.startQuiz());
        }

        const prevQuestionBtn = document.getElementById('prevQuestionBtn');
        const nextQuestionBtn = document.getElementById('nextQuestionBtn');
        const submitQuizBtn = document.getElementById('submitQuizBtn');
        
        if (prevQuestionBtn) {
            prevQuestionBtn.addEventListener('click', () => this.previousQuestion());
        }
        if (nextQuestionBtn) {
            nextQuestionBtn.addEventListener('click', () => this.nextQuestion());
        }
        if (submitQuizBtn) {
            submitQuizBtn.addEventListener('click', () => this.submitQuiz());
        }

        // Certificate buttons
        const downloadCertBtn = document.getElementById('downloadCertBtn');
        if (downloadCertBtn) {
            downloadCertBtn.addEventListener('click', () => this.downloadCertificate());
        }

        // Slide navigation buttons
        const slideButtons = document.querySelectorAll('.slide-btn');
        slideButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const slideNum = parseInt(e.target.dataset.slide);
                this.goToSlide(slideNum);
            });
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case 'ArrowLeft':
                case 'ArrowUp':
                    e.preventDefault();
                    this.previousSlide();
                    break;
                case 'ArrowRight':
                case 'ArrowDown':
                case ' ':
                    e.preventDefault();
                    this.nextSlide();
                    break;
                case 'Home':
                    e.preventDefault();
                    this.goToSlide(1);
                    break;
                case 'End':
                    e.preventDefault();
                    this.goToSlide(this.totalSlides);
                    break;
                case 'Escape':
                    e.preventDefault();
                    this.restartPresentation();
                    break;
            }
        });

        // Add hover effects to interactive elements
        this.addHoverEffects();
    }

    addHoverEffects() {
        // Add hover effects to point items
        const pointItems = document.querySelectorAll('.point-item');
        pointItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.style.transform = 'translateY(-4px) scale(1.02)';
                item.style.boxShadow = '0 10px 25px rgba(255, 215, 0, 0.2)';
            });
            
            item.addEventListener('mouseleave', () => {
                item.style.transform = 'translateY(0) scale(1)';
                item.style.boxShadow = '';
            });
        });

        // Add hover effects to step items
        const stepItems = document.querySelectorAll('.step-item');
        stepItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.style.transform = 'translateX(5px)';
                item.style.boxShadow = '0 4px 15px rgba(255, 215, 0, 0.15)';
            });
            
            item.addEventListener('mouseleave', () => {
                item.style.transform = 'translateX(0)';
                item.style.boxShadow = '';
            });
        });

        // Add hover effects to checklist items
        const checklistItems = document.querySelectorAll('.checklist-item');
        checklistItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.style.transform = 'scale(1.02)';
                item.style.borderColor = '#FFD700';
            });
            
            item.addEventListener('mouseleave', () => {
                item.style.transform = 'scale(1)';
                item.style.borderColor = '';
            });
        });
    }

    showSlide(slideNum) {
        // Hide all slides
        const slides = document.querySelectorAll('.slide');
        slides.forEach(slide => {
            slide.classList.remove('active');
        });

        // Show target slide
        const targetSlide = document.getElementById(`slide-${slideNum}`);
        if (targetSlide) {
            // Add a small delay for smooth transition
            setTimeout(() => {
                targetSlide.classList.add('active');
                this.animateSlideContent(slideNum);
            }, 100);
        }

        this.currentSlide = slideNum;
        this.updateDisplay();
        
        // Actualizar progreso SCORM
        this.updateSCORMProgress();
    }

    animateSlideContent(slideNum) {
        const slide = document.getElementById(`slide-${slideNum}`);
        if (!slide) return;

        // Add different animations based on slide type
        switch(slideNum) {
            case 1:
                this.animateTitleSlide(slide);
                break;
            case 2:
                this.animatePointsSlide(slide);
                break;
            case 4:
                this.animateComparisonSlide(slide);
                break;
            case 5:
                this.animateProcedureSlide(slide);
                break;
            case 9:
                this.animateChecklistSlide(slide);
                break;
            case 10:
                this.animateConclusionSlide(slide);
                break;
            default:
                this.animateDefaultSlide(slide);
        }
    }

    animateTitleSlide(slide) {
        const logo = slide.querySelector('.company-logo h1');
        const accent = slide.querySelector('.logo-accent');
        const title = slide.querySelector('.title-content h2');
        const subtitle = slide.querySelector('.title-content h3');
        const tagline = slide.querySelector('.tagline');

        if (logo) {
            logo.style.opacity = '0';
            logo.style.transform = 'scale(0.8)';
            setTimeout(() => {
                logo.style.transition = 'all 0.6s ease-out';
                logo.style.opacity = '1';
                logo.style.transform = 'scale(1)';
            }, 200);
        }

        if (accent) {
            accent.style.width = '0';
            setTimeout(() => {
                accent.style.transition = 'width 0.8s ease-out';
                accent.style.width = '200px';
            }, 600);
        }

        [title, subtitle, tagline].forEach((element, index) => {
            if (element) {
                element.style.opacity = '0';
                element.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    element.style.transition = 'all 0.5s ease-out';
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }, 800 + (index * 200));
            }
        });
    }

    animatePointsSlide(slide) {
        const points = slide.querySelectorAll('.point-item');
        points.forEach((point, index) => {
            point.style.opacity = '0';
            point.style.transform = 'translateY(30px)';
            setTimeout(() => {
                point.style.transition = 'all 0.4s ease-out';
                point.style.opacity = '1';
                point.style.transform = 'translateY(0)';
            }, index * 150);
        });
    }

    animateComparisonSlide(slide) {
        const beforeSide = slide.querySelector('.before');
        const afterSide = slide.querySelector('.after');
        const arrow = slide.querySelector('.comparison-arrow');

        if (beforeSide) {
            beforeSide.style.opacity = '0';
            beforeSide.style.transform = 'translateX(-30px)';
            setTimeout(() => {
                beforeSide.style.transition = 'all 0.5s ease-out';
                beforeSide.style.opacity = '1';
                beforeSide.style.transform = 'translateX(0)';
            }, 200);
        }

        if (arrow) {
            arrow.style.opacity = '0';
            arrow.style.transform = 'scale(0.5)';
            setTimeout(() => {
                arrow.style.transition = 'all 0.4s ease-out';
                arrow.style.opacity = '1';
                arrow.style.transform = 'scale(1)';
            }, 600);
        }

        if (afterSide) {
            afterSide.style.opacity = '0';
            afterSide.style.transform = 'translateX(30px)';
            setTimeout(() => {
                afterSide.style.transition = 'all 0.5s ease-out';
                afterSide.style.opacity = '1';
                afterSide.style.transform = 'translateX(0)';
            }, 800);
        }
    }

    animateProcedureSlide(slide) {
        const steps = slide.querySelectorAll('.step-item');
        steps.forEach((step, index) => {
            step.style.opacity = '0';
            step.style.transform = 'translateX(-20px)';
            setTimeout(() => {
                step.style.transition = 'all 0.3s ease-out';
                step.style.opacity = '1';
                step.style.transform = 'translateX(0)';
            }, index * 100);
        });
    }

    animateChecklistSlide(slide) {
        const items = slide.querySelectorAll('.checklist-item');
        items.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'scale(0.9)';
            setTimeout(() => {
                item.style.transition = 'all 0.3s ease-out';
                item.style.opacity = '1';
                item.style.transform = 'scale(1)';
                
                // Add a small bounce effect to the checkmark
                const checkmark = item.querySelector('.check');
                if (checkmark) {
                    setTimeout(() => {
                        checkmark.style.transform = 'scale(1.3)';
                        setTimeout(() => {
                            checkmark.style.transition = 'transform 0.2s ease-out';
                            checkmark.style.transform = 'scale(1)';
                        }, 100);
                    }, 200);
                }
            }, index * 120);
        });
    }

    animateConclusionSlide(slide) {
        const messages = slide.querySelectorAll('.message-item');
        const restartBtn = slide.querySelector('#restartBtn');

        messages.forEach((message, index) => {
            message.style.opacity = '0';
            message.style.transform = 'translateY(20px)';
            setTimeout(() => {
                message.style.transition = 'all 0.4s ease-out';
                message.style.opacity = '1';
                message.style.transform = 'translateY(0)';
            }, index * 200);
        });

        if (restartBtn) {
            restartBtn.style.opacity = '0';
            restartBtn.style.transform = 'scale(0.8)';
            setTimeout(() => {
                restartBtn.style.transition = 'all 0.5s ease-out';
                restartBtn.style.opacity = '1';
                restartBtn.style.transform = 'scale(1)';
            }, messages.length * 200 + 300);
        }
    }

    animateDefaultSlide(slide) {
        const animatableElements = slide.querySelectorAll('h2, h3, .commitment-item, .norm-item, .question-item, .analysis-item');
        animatableElements.forEach((element, index) => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(15px)';
            setTimeout(() => {
                element.style.transition = 'all 0.3s ease-out';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 80);
        });
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides) {
            this.goToSlide(this.currentSlide + 1);
        }
    }

    previousSlide() {
        if (this.currentSlide > 1) {
            this.goToSlide(this.currentSlide - 1);
        }
    }

    goToSlide(slideNum) {
        if (slideNum >= 1 && slideNum <= this.totalSlides) {
            this.showSlide(slideNum);
        }
    }

    // Quiz System Methods
    startQuiz() {
        this.quizStarted = true;
        this.currentQuestion = 0;
        this.quizAnswers = [];
        this.startTime = new Date();
        
        // Get participant name
        this.participantName = prompt("Por favor, ingresa tu nombre para el certificado:") || "Participante";
        
        this.goToSlide(17);
        this.loadQuestion();
    }

    loadQuestion() {
        const questionData = this.quizData[this.currentQuestion];
        
        // Update question number and progress
        const questionNumber = document.getElementById('questionNumber');
        const quizProgressFill = document.getElementById('quizProgressFill');
        
        if (questionNumber) {
            questionNumber.textContent = this.currentQuestion + 1;
        }
        
        if (quizProgressFill) {
            const progress = ((this.currentQuestion + 1) / this.quizData.length) * 100;
            quizProgressFill.style.width = `${progress}%`;
        }
        
        // Load question text
        const questionText = document.getElementById('questionText');
        if (questionText) {
            questionText.textContent = questionData.question;
        }
        
        // Load options
        const optionsContainer = document.getElementById('optionsContainer');
        if (optionsContainer) {
            optionsContainer.innerHTML = '';
            
            questionData.options.forEach((option, index) => {
                const optionElement = document.createElement('div');
                optionElement.className = 'option-item';
                optionElement.textContent = `${String.fromCharCode(97 + index)}) ${option}`;
                optionElement.dataset.index = index;
                
                // Check if this option was previously selected
                if (this.quizAnswers[this.currentQuestion] === index) {
                    optionElement.classList.add('selected');
                }
                
                optionElement.addEventListener('click', () => this.selectOption(index));
                optionsContainer.appendChild(optionElement);
            });
        }
        
        // Update navigation buttons
        this.updateQuizNavigation();
    }

    selectOption(index) {
        // Store the answer
        this.quizAnswers[this.currentQuestion] = index;
        
        // Update visual selection
        const options = document.querySelectorAll('.option-item');
        options.forEach((option, i) => {
            if (i === index) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });
        
        // Enable next button
        this.updateQuizNavigation();
    }

    updateQuizNavigation() {
        const prevQuestionBtn = document.getElementById('prevQuestionBtn');
        const nextQuestionBtn = document.getElementById('nextQuestionBtn');
        const submitQuizBtn = document.getElementById('submitQuizBtn');
        
        if (prevQuestionBtn) {
            prevQuestionBtn.disabled = this.currentQuestion === 0;
            prevQuestionBtn.style.opacity = this.currentQuestion === 0 ? '0.5' : '1';
        }
        
        const hasAnswer = this.quizAnswers[this.currentQuestion] !== undefined;
        const isLastQuestion = this.currentQuestion === this.quizData.length - 1;
        
        if (nextQuestionBtn && submitQuizBtn) {
            if (isLastQuestion) {
                nextQuestionBtn.style.display = 'none';
                submitQuizBtn.style.display = hasAnswer ? 'inline-block' : 'none';
            } else {
                nextQuestionBtn.style.display = 'inline-block';
                nextQuestionBtn.disabled = !hasAnswer;
                nextQuestionBtn.style.opacity = hasAnswer ? '1' : '0.5';
                submitQuizBtn.style.display = 'none';
            }
        }
    }

    previousQuestion() {
        if (this.currentQuestion > 0) {
            this.currentQuestion--;
            this.loadQuestion();
        }
    }

    nextQuestion() {
        if (this.currentQuestion < this.quizData.length - 1 && this.quizAnswers[this.currentQuestion] !== undefined) {
            this.currentQuestion++;
            this.loadQuestion();
        }
    }

    submitQuiz() {
        // Calculate score
        let correctAnswers = 0;
        this.quizAnswers.forEach((answer, index) => {
            if (answer === this.quizData[index].correct) {
                correctAnswers++;
            }
        });
        
        const score = Math.round((correctAnswers / this.quizData.length) * 100);
        const endTime = new Date();
        const duration = Math.round((endTime - this.startTime) / 1000 / 60); // minutes
        
        this.quizCompleted = true;
        this.finalScore = score;
        this.totalTime = `${duration} minutos`;
        
        // Enviar puntuación a SCORM
        this.submitSCORMScore(score);
        
        // Show results and go to certificate
        if (score >= 80) {
            alert(`¡Felicitaciones! Has aprobado con ${score}% (${correctAnswers}/${this.quizData.length} respuestas correctas)`);
            this.showCertificate();
        } else {
            alert(`Has obtenido ${score}% (${correctAnswers}/${this.quizData.length} respuestas correctas). Necesitas 80% para aprobar. ¡Inténtalo de nuevo!`);
            this.resetQuiz();
        }
    }

    resetQuiz() {
        this.quizStarted = false;
        this.currentQuestion = 0;
        this.quizAnswers = [];
        this.quizCompleted = false;
        this.goToSlide(16);
    }

    showCertificate() {
        this.goToSlide(18);
        
        // Update certificate with participant data
        const participantNameElement = document.getElementById('participantName');
        const completionDateElement = document.getElementById('completionDate');
        const finalScoreElement = document.getElementById('finalScore');
        const totalTimeElement = document.getElementById('totalTime');
        
        if (participantNameElement) {
            participantNameElement.textContent = this.participantName;
        }
        
        if (completionDateElement) {
            const now = new Date();
            completionDateElement.textContent = now.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        if (finalScoreElement) {
            finalScoreElement.textContent = this.finalScore;
        }
        
        if (totalTimeElement) {
            totalTimeElement.textContent = this.totalTime;
        }
    }

    downloadCertificate() {
        // Simple implementation - in a real app, you'd generate a PDF
        const certificateContent = `
CERTIFICADO DE FINALIZACIÓN
COLTEFINANCIERA

Capacitación Servicio al Cliente - Segundo Semestre 2025

Se certifica que ${this.participantName} ha completado exitosamente
la capacitación en Servicio al Cliente, incorporando las
recomendaciones de Auditoría Interna.

Fecha: ${new Date().toLocaleDateString('es-ES')}
Puntuación: ${this.finalScore}%
Duración: ${this.totalTime}

Coltefinanciera - Siempre a tu lado
        `;
        
        const blob = new Blob([certificateContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Certificado_${this.participantName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        // Show success message
        alert('¡Certificado descargado exitosamente!');
    }

    restartPresentation() {
        // Reset all quiz data
        this.quizStarted = false;
        this.currentQuestion = 0;
        this.quizAnswers = [];
        this.quizCompleted = false;
        this.finalScore = 0;
        this.totalTime = "";
        this.participantName = "";
        
        this.goToSlide(1);
        
        // Add visual feedback for restart
        const restartBtn = document.getElementById('restartBtn');
        if (restartBtn) {
            restartBtn.style.transform = 'scale(0.95)';
            setTimeout(() => {
                restartBtn.style.transform = 'scale(1)';
            }, 150);
        }
    }

    updateDisplay() {
        // Update progress bar
        const progressFill = document.getElementById('progressFill');
        if (progressFill) {
            const progressPercent = (this.currentSlide / this.totalSlides) * 100;
            progressFill.style.width = `${progressPercent}%`;
        }

        // Update current slide indicator
        const currentSlideElement = document.getElementById('currentSlide');
        if (currentSlideElement) {
            currentSlideElement.textContent = `Slide ${this.currentSlide} de ${this.totalSlides}`;
        }

        // Update timer
        const timerElement = document.getElementById('timer');
        if (timerElement) {
            timerElement.textContent = `Timer: ${this.slideTimers[this.currentSlide]}`;
        }

        // Update navigation button states
        this.updateNavigationButtons();

        // Update slide navigation buttons
        this.updateSlideButtons();
    }

    updateNavigationButtons() {
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');

        if (prevBtn) {
            prevBtn.disabled = this.currentSlide === 1;
            prevBtn.style.opacity = this.currentSlide === 1 ? '0.5' : '1';
        }

        if (nextBtn) {
            nextBtn.disabled = this.currentSlide === this.totalSlides;
            nextBtn.style.opacity = this.currentSlide === this.totalSlides ? '0.5' : '1';
        }
    }

    updateSlideButtons() {
        const slideButtons = document.querySelectorAll('.slide-btn');
        slideButtons.forEach(btn => {
            const slideNum = parseInt(btn.dataset.slide);
            if (slideNum === this.currentSlide) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    // Auto-advance functionality (optional)
    startAutoAdvance(intervalMs = 30000) { // 30 seconds default
        this.autoAdvanceInterval = setInterval(() => {
            if (this.currentSlide < this.totalSlides) {
                this.nextSlide();
            } else {
                this.stopAutoAdvance();
            }
        }, intervalMs);
    }

    stopAutoAdvance() {
        if (this.autoAdvanceInterval) {
            clearInterval(this.autoAdvanceInterval);
            this.autoAdvanceInterval = null;
        }
    }

    // Accessibility features
    announceSlideChange() {
        const slide = document.getElementById(`slide-${this.currentSlide}`);
        if (slide) {
            const title = slide.querySelector('h2');
            if (title && 'speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(`Slide ${this.currentSlide}: ${title.textContent}`);
                utterance.rate = 0.8;
                utterance.volume = 0.5;
                speechSynthesis.speak(utterance);
            }
        }
    }
}

// Initialize the presentation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new PresentationApp();
    
    // Add some additional interactivity
    
    // Add ripple effect to buttons
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });

    // Add smooth scrolling for better UX
    document.documentElement.style.scrollBehavior = 'smooth';

    // Add focus management for better accessibility
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });

    document.addEventListener('mousedown', () => {
        document.body.classList.remove('keyboard-navigation');
    });

    // Performance optimization: Preload next slide content
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Slide is visible, can perform any necessary operations
                const slideId = entry.target.id;
                console.log(`Slide ${slideId} is now visible`);
            }
        });
    });

    // Observe all slides
    document.querySelectorAll('.slide').forEach(slide => {
        observer.observe(slide);
    });

    // Add window resize handler for responsive adjustments
    window.addEventListener('resize', () => {
        // Adjust any layout elements if needed
        app.updateDisplay();
    });

    // Expose app instance globally for debugging
    window.presentationApp = app;
});

// CSS for ripple effect
const style = document.createElement('style');
style.textContent = `
    button {
        position: relative;
        overflow: hidden;
    }
    
    .ripple {
        position: absolute;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: rippleEffect 0.6s ease-out;
        pointer-events: none;
    }
    
    @keyframes rippleEffect {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    .keyboard-navigation button:focus {
        outline: 2px solid #FFD700;
        outline-offset: 2px;
    }
`;
document.head.appendChild(style);